from unittest import TestCase


class TestUnits(TestCase):

    def test_units(self):
        assert 5 * 5 == 25
