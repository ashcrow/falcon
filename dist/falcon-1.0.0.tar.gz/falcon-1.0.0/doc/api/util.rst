.. _util:

Utilities
=========

URI Functions
-------------

.. automodule:: falcon.util.uri
    :members:

Miscellaneous
-------------

.. automodule:: falcon
    :members: deprecated, http_now, dt_to_http, http_date_to_dt, to_query_str

.. autoclass:: falcon.util.TimezoneGMT
    :members:
