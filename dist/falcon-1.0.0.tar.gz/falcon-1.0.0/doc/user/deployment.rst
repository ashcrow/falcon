.. _deployment:

Deploying Your Web API
======================

[talk about, diagram async, host, etc.]

[async front, async to backend options - asyncio, gevent, etc.]